let users = [
    {
        username:"Sumit"
    },
    {
        username:"Sri"
    },
    {
        username:"Alisha"
    },
    {
        username:"Surajit"
    },
    {
        username:"Monty"
    },
    {
        username:"Something else"
    },
];

// users.forEach((val) => {
//     console.log("Value will be printed");
//     setTimeout(() => console.log(val), 5000)
// })


for (let i = 1; i < users.length; i++) {
    setTimeout(function timer() {
      console.log("User "+users[i].username);
    }, i * 3000);
  }