var axios = require('axios');

var config = {
  method: 'get',
  url: 'https://api.us.onelogin.com/api/1/users/135071857/auth_factors',
  headers: { 
    'Authorization': 'Bearer cd1cef745982a8b58c5b848e23f72a246761666aa593d17573e79ced61ec90c8'
  }
};

axios(config)
.then(function (response) {
  //console.log(JSON.stringify(response.data));
  console.log("")
})
.catch(function (err) {
  console.log(err.response.data);
});