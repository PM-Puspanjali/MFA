const csv = require('csv-parser');
const fs = require('fs');
var axios = require('axios');
const { Console } = require('console');

let BASE_URL = "https://api.us.onelogin.com/api/1";

const options = {
  method: 'get',
  url: 'http://localhost:3001/accessToken'
};

let users = [];
let token;

fs.createReadStream('enrol-1.csv')
      .pipe(csv())
      .on('data', (row) => {
        //Inserting into users array
        users.push(row.username);
        
        console.log("----------------------");
        console.log(row);
        console.log(users.length);
        console.log("----------------------");
      })
      .on('end', () => {
        console.log('CSV file successfully processed');
        axios(options)
        .then(response => {
          console.log('access token generated '+response.data.token);
          token = response.data.token;
        })
        .catch(error => console.log(error))

        let k = users.length;
        for (let i = 0; i < k; i++) {
          setTimeout(function timer() {
            console.log(users[i]);
            //
            
            const options = {
              method: 'post',
              url: 'http://localhost:3001/user',
              params:{
                username: users[i],
		//mobile: users[i].mobile,
                token:token
              }
            };
           
            axios(options)
            .then((response) => {
              if(response.data.message && response.data.message.substring(response.data.message.length-3,response.data.message.length)==401){
                console.log("Error Message: "+response.data.message)
                let options1 = {
                  method: 'get',
                  url: 'http://localhost:3001/accessToken'
                };
                axios(options1)
                .then(response => {
                  console.log('access token generated '+response.data.token);
                  token = response.data.token;
                })
                .catch(error => console.log(error))
                //
              }else{
                console.log(JSON.stringify(response.data))
              }
            })
            .catch((error) => {
              console.log("Error occured for user "+users[i].userid)
              console.log("Error Message: "+error.response.data.message)
              
            })
            //
          }, i==0?2000:i*2000);
        }

      });




