var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var fs = require('fs');
var url = require('url');
var axios = require('axios');
const ndjson = require('ndjson');
var cors = require('cors');
var queue = require('express-queue');
var http = require('http');
var https = require('https');

let BASE_URL = "https://api.us.onelogin.com/api/1";
let access_token;

var privateKey  = fs.readFileSync('ssl/privateKey.key', 'utf8');
var certificate = fs.readFileSync('ssl/public.crt', 'utf8');

var credentials = {key: privateKey, cert: certificate};

var corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}

// let obtainAccessToken = () => {
//   console.log('in the function body');
//   var config = {
//     method: 'get',
//     url: 'http://localhost:3000/accessToken'
//   }

//   axios(config)
//   .then(function (response) {
//     console.log('function has returned the code')
//     console.log(response.data.access_token);
//     return response.data.access_token;
//   })
//   .catch(function (error) {
//     console.log(error);
//   });

// };

var rawBodySaver = function (req, res, buf, encoding) {
  if (buf && buf.length) {
    req.rawBody = buf.toString(encoding || 'utf8');
  }
}
//app.use(queue({ activeLimit: 2, queuedLimit: -1 }));
app.use(bodyParser.json({ verify: rawBodySaver }));
app.use(bodyParser.urlencoded({ verify: rawBodySaver, extended: true }));
app.use(bodyParser.raw({ verify: rawBodySaver, type: '*/*' }));

// create application/json parser
var jsonParser = bodyParser.json();
// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ type: 'application/*+json', extended: true });
//Parse NDJSON
// var ndjsonParser = ndjsonParser();

async function getUserIDFromUserName(username) {
    var config = {
        method: 'get',
        url: BASE_URL+'/users?username='+username,
        headers: { 
          'Authorization': 'bearer:'+access_token
        }
      };
      
      axios(config)
      .then(function (response) {
        //console.log(JSON.stringify(response.data));
        return response.data;
      })
      .catch(function (error) {
        //console.log(error);
        return error;
      });
};



app.post('/user', jsonParser, (req, res) => {
    //console.log('printing req body');
    //console.log(req.body);
    let username = req.query.username;
    let token = req.query.token;
    //let url = BASE_URL+"/users/"+username;
    
    var getOLId = {
        method: 'get',
        url: BASE_URL+'/users?username='+username,
        headers: { 
          'Authorization': 'bearer:'+token
        }
    };
      
      axios(getOLId)
      .then(function (response) {
        let $logMsg = `${Date.now()},User ${response.data.data[0].username},${response.data.data[0].id},${response.data.data[0].custom_attributes.MobilePhone},`
        console.log(JSON.stringify(response.data.data[0].id));
        enrollmentData = JSON.stringify({
          "factor_id": 71286,
          "display_name": "Text Message (SMS)",
          "number": response.data.data[0].custom_attributes.MobilePhone,
          "verified": true
        })
        var enrollmfa = {
          method: 'post',
          url: BASE_URL+'/users/'+response.data.data[0].id+'/otp_devices',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'bearer:'+token
          },
          data:enrollmentData
        };

        axios(enrollmfa)
        .then(function (response) {
          let $finallogMsg = $logMsg+""+response.data.status.message
          // 'a' flag stands for 'append'
          const log = fs.createWriteStream('log.txt', { flags: 'a' });
          // on new log entry ->
          log.write(`${$finallogMsg}\n`);
          res.json(response.data);
        })
        .catch(function (error) {
          let $finallogMsg = $logMsg+""+JSON.stringify(error)
          // 'a' flag stands for 'append'
          const log = fs.createWriteStream('log.txt', { flags: 'a' });
          // on new log entry ->
          log.write(`${$logMsg}\n`);
          res.json(error);
        });
      })
      .catch(function (error) {
        let $finallogMsg = `${Date.now()},`+JSON.stringify(error)
        // 'a' flag stands for 'append'
        const log = fs.createWriteStream('log.txt', { flags: 'a' });
          // on new log entry ->
          log.write(`${$finallogMsg}\n`);
        console.log(error);
        res.json(error);
      });
});

//phone number
app.post('/phone', cors(corsOptions), jsonParser, (req, res) => {
  console.log('printing req body');
  console.log(req.body);
  let username = req.body.username;
  let searchfield = req.body.usernameType;
  //let url = BASE_URL+"/users/"+username;

  var atc = {
    method: 'get',
    url: 'http://localhost:3000/accessToken'
  }

  axios(atc)
  .then(function (response) {
  console.log(response.data)
  var getOLId = {
      method: 'get',
      url: BASE_URL+'/users?'+searchfield+'='+username,
      headers: { 
        'Authorization': 'bearer:'+response.data.token
      }
  };
    
    axios(getOLId)
    .then(function (response) {
      console.log(JSON.stringify(response.data.data));
      res.json({'Success':'Your phone number ending with '+response.data.data[0].phone.substring(response.data.data[0].phone.length - 4, response.data.data[0].phone.length)+' is registered for SMS MFA.'});
    })
    .catch(function (error) {
      console.log(error);
      res.json(error);
    });
  })
  .catch(err => res.json(err))
});
//phone number

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '/phone.html'));
})

//Function to retrieve access token
app.get('/accessToken', (req, res) => {
  var data = JSON.stringify({
    "grant_type": "client_credentials"
  });

  var config = {
    method: 'post',
    url: 'https://api.us.onelogin.com/auth/oauth2/v2/token',
    headers: { 
      'Content-Type': 'application/json', 
      'Authorization': 'client_id:07118f399fd17884afbaa235367828698c7d23e955145a1c93c0c2226d09f0be, client_secret:ce1a91cac73f6dbe4e5bfa4cee6455b799f84c5312595605be62afcd8dd9e19a'
    },
    data : data
  };

  axios(config)
  .then(function (response) {
    res.json({"token":response.data.access_token});
  })
  .catch(function (error) {
    res.json({"error":error})
  });
});

app.post('/logsParser', (req, res) => {
  console.log(req.body);
  console.log('-----------------------------');
  var receivedlogs = Object.keys(req.body);
  console.log(JSON.parse(receivedlogs[0]).event.event_type_id);
  var event13 = JSON.parse(receivedlogs[0]).event.event_type_id;
  if(event13 == 13){
    //
    enrollmentData = JSON.stringify({
      "factor_id": 69043,
      "display_name": "OneLogin SMS",
      "number": "+917003752368",
      "verified": true
    })
    var enrollmfa = {
      method: 'post',
      url: BASE_URL+'/users/'+JSON.parse(receivedlogs[0]).event.user_id+'/otp_devices',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'bearer:1ec69abc3da8954d92c9b0dc5264cbbf3e98b394d479301690ddbe99fb06a112'
      },
      data:enrollmentData
    };

    axios(enrollmfa)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      res.json(error);
    });
    //
  }else{
    console.log('event not 13');
    res.status(200).send('OK')
  }
  // fs.createReadStream('data.txt')
  // .pipe(ndjson.parse())
  // .on('data', function(obj) {
  //   console.log(obj);
  // })

  
 //res.status(200).send('OK');
});

app.get('/getusers/startdate', async (req, res) => {

  console.log(req.query.startdate)

  var atc = {
    method: 'get',
    url: 'http://localhost:3000/accessToken'
  }

  axios(atc)
  .then(function (response) {
    console.log('function has returned the code')
    console.log(response.data.token);
    access_token = response.data.token;

    var after_cursor = 1;
    
    /*Mixed Axios*/
      console.log("initial call begins")
      var config = {
        method: 'get',
        url: after_cursor==1?'https://api.us.onelogin.com/api/1/users?custom_attributes.StartDate='+req.query.startdate:'https://api.us.onelogin.com/api/1/users?after_cursor='+after_cursor,
        headers: { 
          'Authorization': 'bearer:'+access_token
        }
      };
  
    axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
      // res.json(response.data.data);
      after_cursor = response.data.pagination.after_cursor;
      console.log("Number of users with this start date: "+response.data.data.length)
      if(response.data.data.length>0){
      let pendingActivationUsers = response.data.data;
      pendingActivationUsers.forEach(pendingUser => {
        if(pendingUser.custom_attributes.MobilePhone!=null&&pendingUser.custom_attributes.MobilePhone.length >10){
          /*Activating MFA for users - Start*/
          enrollmentData = JSON.stringify({
            "factor_id": 70175,
            "display_name": "Text Message (SMS)",
            "number": pendingUser.custom_attributes.MobilePhone,
            "verified": true
          })
          var enrollmfa = {
            method: 'post',
            url: BASE_URL+'/users/'+pendingUser.id+'/otp_devices',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'bearer:'+access_token
            },
            data:enrollmentData
          };

          axios(enrollmfa)
          .then(function (response) {
            console.log(response.data);
          })
          .catch(function (error) {
            console.log(error);
          });
          /*Activating MFA for users - End*/
        }else{
          res.send("This user has no phone number")
        }
        });
      }else{
      res.send("No user found with given start date")
      }
    })
    .catch(function (error) {
      res.json(error);
    });
  })
  .catch(function (error) {
    res.json(error);
  });
  
});

// app.listen(process.env.PORT || 3000, ()=> {
//     console.log('Server is up and listening on port 8080');
// });

var httpServer = http.createServer(app);
var httpsServer = https.createServer(credentials, app);

httpServer.listen(3000);
httpsServer.listen(443);